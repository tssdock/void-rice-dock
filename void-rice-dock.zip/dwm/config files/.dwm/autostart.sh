#! /bin/bash 
feh --bg-fill --randomize --no-fehbg ~/Pictures/wallpapers/* &
picom --config  $HOME/.config/picom/picom.conf &
nm-applet &
volumeicon &
xrandr --output DP-0 --primary --output DVI-D-0 --right-of DP-0 &
setxkbmap -model pc105 -layout pl &
lxpolkit &
xinput --set-prop 'Gaming Mouse' 'libinput Accel Profile Enabled' 0, 1 &
xinput --set-prop 'SINO WEALTH Gaming KB  Mouse' 'libinput Accel Profile Enabled' 0, 1 &
dunst &
slstatus &
/usr/libexec/xfce-polkit &
pulseaudio --daemonize=no --exit-idle-time=-1 &
