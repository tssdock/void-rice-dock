#!/bin/sh

crit=70 # critical temperature

read -r temp </sys/class/hwmon/hwmon1/temp1_input
temp=${temp%???}

if [ "$temp" -lt "$crit" ] ; then
    printf "$ICONn%s°C" "$temp"
else
    printf "$ICONc%s°C" "$temp"
fi