#!/bin/sh

repo=$(checkupdates | wc -l)
aur=$(yay -Qua | wc -l)

echo "R:$repo A:$aur"