#!/bin/bash 

dnt="$(date +"%a, %B %d %l:%M %p"| sed 's/  / /g')"
echo -e "$dnt - "
