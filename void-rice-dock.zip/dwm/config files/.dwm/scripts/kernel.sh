#! /bin/bash 

kern="$(uname -r)"
echo -e "$kern"
