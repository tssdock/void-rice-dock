Move ".dwm" to the home directory. - autostart apps and dwmblocks scripts.
Move "dwm.desktop" to /usr/share/xsessions/ directory. - File which lets your dm run dwm